import { Text, SafeAreaView, StyleSheet, TouchableOpacity, TextInput   } from 'react-native';
import React from "react"

// You can import supported modules from npm
import { Card } from 'react-native-paper';

// or any files within the Snack


export default class Login extends React.Component() {
  constructor(){
    super();
    this.state={
      email:"",
      password:""
    }
  }
  executeSignIn=()=>{
    this.props.navigation.navigate("Dashboard")
  }
  registerPage=()=>{
    this.props.navigation.navigate("Register")
  }
  render(){
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.paragraph}>
        Login
      </Text>
      <TextInput placeholder={"Email"} onChangeText={(val)=>{
        this.setState({
          email:val
        })
      }}/>
      <TextInput placeholder={"Password"} onChangeText={(val)=>{
        this.setState({
          password:val
        })
      }}/>
      
      <TouchableOpacity onPress={()=>{this.registerPage}}>
        <Text>Register Here</Text>
      </TouchableOpacity>
      <TouchableOpacity onPress={()=>{this.executeSignIn}}>
        <Text>Login Now</Text>
      </TouchableOpacity>
    </SafeAreaView>
  );
}
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    backgroundColor: '#ecf0f1',
    padding: 8,
  },
  paragraph: {
    margin: 24,
    fontSize: 18,
    fontWeight: 'bold',
    textAlign: 'center',
  },
  loginButton:{
    width:50,
    height:50,
    backgroundColor:"#32f1e4",
    justifyContent:'center',
    alignItems:"center"
  },
  registerButton:{
    width:50,
    height:50,
    backgroundColor:"#32f1e4",
    justifyContent:'center',
    alignItems:"center"
  },
  textInput:{
    width:"100%",
    height:25,
    backgroundColor:"#32f1e4"
  }
});