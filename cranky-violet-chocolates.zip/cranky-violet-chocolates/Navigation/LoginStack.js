import { Text, SafeAreaView, StyleSheet } from 'react-native';
import React from "react"
import {createStackNavigator} from 'react-navigation/stack'
import {NavigationContainer} from 'react-navigaton/native'
// You can import supported modules from npm
import { Card } from 'react-native-paper';
import Home from '../Screens/Home'
import Login from '../Screens/Login'
import Register from '../Screens/Register'
// or any files within the Snack


const LoginStack=createStackNavigator
const StackNav = () => {
  return(
  <LoginStack.Navigator initialRouteName="Login"  screenOptions={{
    headerShown: false,
    gestureEnabled: false
  }}>
    <LoginStack.Screen name="Login" component={Login} />
    <LoginStack.Screen name="RegisterScreen" component={Register} />
    <LoginStack.Screen name="Dashboard" component={Home} />
  </LoginStack.Navigator>
  )
}
export default StackNav